#!/usr/bin/env python
# -*- coding: UTF-8 -*-

import sys

sys.path.insert(0, '/usr/share/pyregedit')

from Controllers import Controller

controller = Controller()
controller.initApp() # Init app
